# Integer
print("hello world")
int_var = 42

# Floating-point number
float_var = 3.14

# String
str_var = "Hello, World!"

# Boolean
bool_var = True

# List (ordered, mutable collection)
list_var = [1, 2, 3, 4, 5]

# Tuple (ordered, immutable collection)
tuple_var = (10, 20, 30)

# Set (unordered, mutable collection)
set_var = {1, 2, 2, 3, 3, 4}

# Dictionary (key-value pairs)
dict_var = {"name": "Alice", "age": 30, "city": "Wonderland"}

# NoneType (represents the absence of a value)
none_var = None

# Printing the variables and their types
print("Integer:", int_var, type(int_var))
print("Float:", float_var, type(float_var))
print("String:", str_var, type(str_var))
print("Boolean:", bool_var, type(bool_var))
print("List:", list_var, type(list_var))
print("Tuple:", tuple_var, type(tuple_var))
print("Set:", set_var, type(set_var))
print("Dictionary:", dict_var, type(dict_var))
print("NoneType:", none_var, type(none_var))
